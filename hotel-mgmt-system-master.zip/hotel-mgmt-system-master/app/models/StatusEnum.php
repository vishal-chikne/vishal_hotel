<?php

namespace models;


abstract class StatusEnum
{
    const PENDING_STR = "PENDING";
    const CONFIRMED_STR = "CONFIRMED";
    const CANCELLED_STR = "CANCELLED";
}
